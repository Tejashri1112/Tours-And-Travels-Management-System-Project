package com.example.demo.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.example.demo.Entity.CProfile;
import com.example.demo.Entity.Login;
import com.example.demo.Entity.SignUp;
import com.example.demo.Entity.Tours;
import com.example.demo.Entity.UBookPackage;
import com.example.demo.Repository.Cprofile;
import com.example.demo.Repository.SignUpRepo;
import com.example.demo.Repository.TourRepo;
import com.example.demo.Repository.uBookPackage;

@Service
public class SignUpService {
	
	@Autowired
	SignUpRepo repo;
	
	@Autowired
	TourRepo tourRepo;
	
	@Autowired
	Cprofile cprofileRepo;
	
	@Autowired
	uBookPackage packRepo;
//registration 
	public SignUp register(SignUp signup) {
		
		return repo.save(signup);
	}

	//login
	  public Map<String, String> login(String email, String password, String role) {
	        Map<String, String> response = new HashMap<>();
	        try {
	            SignUp user = repo.findByEmail(email);
	            if (user != null) {
	                if (password.equals(user.getPassword())) {
	                    if (role.equals(user.getRole())) {
	                        response.put("success", "true");
	                        response.put("message", "Login successful");
	                        response.put("role", role); // Return the role (admin or user) on successful login
	                    } else {
	                        response.put("success", "false");
	                        response.put("message", "Role mismatch"); // Role mismatch
	                    }
	                } else {
	                    response.put("success", "false");
	                    response.put("message", "Incorrect password"); // Incorrect password
	                }
	            } else {
	                response.put("success", "false");
	                response.put("message", "User not found"); // User not found
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            response.put("success", "false");
	            response.put("message", "An error occurred"); // Exception occurred
	        }
	        return response;
	    }
// Save tours
	public Tours saveTours(Tours tours) {
		// TODO Auto-generated method stub
		return tourRepo.save(tours);
	}
	
	// get all tours
	public List<Tours> findAllTours() {
		// TODO Auto-generated method stub
		return tourRepo.findAll();
	}
	
	// save profile
	public CProfile createProfile(CProfile profile) {
		// TODO Auto-generated method stub
		return cprofileRepo.save(profile);
	}
// show profile
	public List<CProfile> showProfile() {
		
		return cprofileRepo.findAll();
	}

	

	public Optional<CProfile> findById(int id) {
		
		return cprofileRepo.findById(id);
	}

	public List<CProfile> findAllCustomers() {
		
		return cprofileRepo.findAll();
	}

	public List<UBookPackage> findAllBooking() {
		// TODO Auto-generated method stub
		return packRepo.findAll();
	}
//booking 
public UBookPackage savepackage(UBookPackage pack) {
		
		return packRepo.save(pack);
	}


   public Optional<UBookPackage> findBookingById(int id)
   {
	   return packRepo.findById(id);
   }

public List<UBookPackage> findBookingByName(String email) {
	// TODO Auto-generated method stub
	return packRepo.findBookingByEmail(email);
}


//Update Bookings
public boolean updateBooking(UBookPackage booking, int id) {
    try {
        Optional<UBookPackage> optionalBooking = packRepo.findById(id);

        if (optionalBooking.isPresent()) {
            UBookPackage existingBooking = optionalBooking.get();
            existingBooking.setFirstName(booking.getFirstName());
            existingBooking.setLastName(booking.getLastName());
            existingBooking.setEmail(booking.getEmail());
            existingBooking.setPhoneNo(booking.getPhoneNo());
            existingBooking.setChoosePackage(booking.getChoosePackage());
            existingBooking.setDepartureDate(booking.getDepartureDate());
            existingBooking.setReturnDate(booking.getReturnDate());
            existingBooking.setNoOfAdults(booking.getNoOfAdults());
            existingBooking.setNoOfChilds(booking.getNoOfChilds());
            existingBooking.setSpecialRequest(booking.getSpecialRequest());

            packRepo.save(existingBooking);
            return true;
        } else {
            return false;
        }
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}

//delete booking record
        public void deletePackage(int id) {
          packRepo.deleteById(id);
           }

}

