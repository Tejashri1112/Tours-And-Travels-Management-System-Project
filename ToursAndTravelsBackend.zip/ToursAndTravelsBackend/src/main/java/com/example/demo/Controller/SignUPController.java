package com.example.demo.Controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.CProfile;
import com.example.demo.Entity.Login;
import com.example.demo.Entity.SignUp;
import com.example.demo.Entity.Tours;
import com.example.demo.Entity.UBookPackage;
import com.example.demo.Service.SignUpService;


@RestController
@CrossOrigin
public class SignUPController {
	
	@Autowired
	SignUpService service;
	
	@PostMapping("register")
	public SignUp register(@RequestBody SignUp signup)
	{
		return service.register(signup);
	}
	 @PostMapping("login")
	    public Map<String, String> login(@RequestBody Login loginRequest) {
	        return service.login(loginRequest.getEmail(), loginRequest.getPassword(), loginRequest.getRole());
	    }
	
	 
	 //save tours by admin
	  
	 @PostMapping("saveTours")
	 public Tours saveTours(@RequestBody Tours tours)
	 {
		 return service.saveTours(tours);
	 }
	 
	 @GetMapping("AllTours")
	 public List<Tours> findAllTours(){
		 return service.findAllTours();
	 }
	 
	 //create profile by user
	 @PostMapping("createProfile")
	 public CProfile createProfile(@RequestBody CProfile profile) {
		return service.createProfile(profile);
		 
	 }
	 
	 //show profile by user
	 @GetMapping("showProfile")
	 public List<CProfile> readAllTasks()
		{
			
			try {
				return service.showProfile();
			}
			catch (Exception e)
			{
				e.printStackTrace();
				return null;
			}
		}
	 @GetMapping("findByIdProfile/{id}")
	 public Optional<CProfile> findById(@PathVariable int id){
		 return service.findById(id);
	 }
	 
	 @GetMapping("AllCustomers")
	 public List<CProfile> findAllCustomers(){
		 return service.findAllCustomers();
	 }
	 
	 
	 //save package by admin
	  @PostMapping("savePackage")
	 public UBookPackage savePackage(@RequestBody UBookPackage pack) {
		 return service.savepackage(pack);
	 }
	//get booking
		 
		 @GetMapping("findAllBooking")
		 public List<UBookPackage> findAllBooking()
		 {
			 return service.findAllBooking();
		 }
		 
		 //fingbookingById
	  @GetMapping("findBooking/{id}")
	  public Optional<UBookPackage> findBookingById(@PathVariable int id)
	  {
		  return service.findBookingById(id);
	  }
	  
	  //findBookingByEmail
	  @GetMapping("findBookingByEmail/{email}")
	  public List<UBookPackage> findBookingByName(@PathVariable String email)
	  {
		  return service.findBookingByName(email);
	  }
	  
	  // Update the booking
	  @PutMapping("editBooking/{id}")
	  public boolean editTask(@RequestBody UBookPackage booking,@PathVariable int id) {
	  	return service.updateBooking(booking,id);
	  }
	  	
	  //Delete the Booking
	  @DeleteMapping("deleteBooking/{id}")
	    public void deleteBooking(@PathVariable int id) {
	        service.deletePackage(id);
	    }
	
}