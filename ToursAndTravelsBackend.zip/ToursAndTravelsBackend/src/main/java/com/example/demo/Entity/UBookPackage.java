package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

@Entity
public class UBookPackage {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Size(min=6,max=15)
	private String firstName;
	@Size(min=6,max=15)
	private String lastName;
	@Email(message = "Enter valid email with @gmail.com")
	private String email;
	@Size(min=10,max=10,message = "enter 10 digit mobile number")
	private String phoneNo;
	private String choosePackage;
	private String departureDate;
	private String returnDate;
	private int noOfAdults;
	private int noOfChilds;
    private String SpecialRequest;
	public String getSpecialRequest() {
		return SpecialRequest;
	}
	public void setSpecialRequest(String specialRequest) {
		SpecialRequest = specialRequest;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getChoosePackage() {
		return choosePackage;
	}
	public void setChoosePackage(String choosePackage) {
		this.choosePackage = choosePackage;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public int getNoOfChilds() {
		return noOfChilds;
	}
	public void setNoOfChilds(int noOfChilds) {
		this.noOfChilds = noOfChilds;
	}

}
