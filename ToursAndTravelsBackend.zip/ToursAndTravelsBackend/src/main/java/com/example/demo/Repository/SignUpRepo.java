package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.SignUp;

public interface SignUpRepo extends JpaRepository<SignUp, Integer> {

//	int countByEmail(String email);
//
SignUp findByEmail(String email);

}
